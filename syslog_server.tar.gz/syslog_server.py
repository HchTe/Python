from abc import ABC, abstractmethod
from random import randint
from logs import *
class main(ABC):
    @abstractmethod
    def username(self, a):
        print('user:', a)

    @abstractmethod
    def password(self, p):
        print('pass:', p)

    
    def premium(self):
        print('premium')

    
    def location(self, l):
        print('logged from:', l)

    
    def browser(self, b):
        print('browser used:', b)

    def ip(self, i):
        print('user ip:', i)
    
    def device(self, h):
        print('logged from', h, "device")

class user_track(main):
    def username(self, a):
        print('username:', a)
    
    def password(self, p):
        print('hashed password:', p)
    
    def premium(self):
        if r % 2 == 0:
            print('user has premium', True)
        else:
            print('user has premium', False)

class user_loc(main):
    def location(self, l):
        print('logged from:', l)

    def username(self, a):
        print()

    def password(self, p):
        print('pass:', p)
    
    def browser(self, b):
        print('browser used:', b)
    
    def ip(self, i):
        print("user's public ip:", i)
    
print('_' *30)
print('User managment:')

user_obj = user_track()
user_obj.username(a)
user_obj.password(p)
user_obj.premium()

print("_" *30)
print('User log in statistics:')

user_l = user_loc()
user_obj.username(a)
user_l.location(l)
user_l.browser(b)
user_l.ip(i)
print('_' *30)