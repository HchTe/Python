from random import randint

user_l = ['Hector', 'rat', 'raven', 'Dirk Struan', 'Joan of arc']
r = randint(0, 4)
a = user_l[r]

pw_hashed = ['ashfds131234', '1a4t626asgs23', '124sdh77enjf', '14t6q2Zsastda', '135qasfdhqe35qy']
p = pw_hashed[r]

user_locations = ['Troy', 'sewers', 'graveyard', "Hong Kong",  'France']
l = user_locations[r]
user_browser = ['firefox', 'chrome', 'opera', 'vivaldi', 'edge']
b = user_browser[r]

user_ip = ['85.31.15.20', '20.51.17.84', '170.150.21.24', '2.15.224.5', '60.31.128.45']
i = user_ip[r]